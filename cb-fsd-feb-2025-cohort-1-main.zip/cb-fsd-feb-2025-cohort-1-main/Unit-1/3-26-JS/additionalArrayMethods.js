const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

//old way to write this operation
// const evenNumbers = numbers.filter(function (number) {
//   return number % 2 === 0;
// });

const evenNumber = numbers.filter(number => number % 2 === 0 ) 

const words = ["spray", "elite", "exuberant", "destruction", "present"];

const longWords = words.filter(word => word.length >= 6)

// Every method -- checks if all elements pass a test

const allEven = evenNumber.every(number => number % 2 === 0)

console.log(allEven)

const myArray = []