
//old way

function welcome(name){
    return `Welcome ${name}`
}

//new way
// => means return
const welcome = (name) => `Welcome ${name} !`

// old way
// function sumTwoNumbers(a,b){
//     const result = a + b
//     return result + 5
// }

//new way. If there's additional logic in the function, we need to reintroduce the return statement as well as the curly braces
const sumTwoNumbers = (a,b) => {
    const result = a + b
    return result + 5
}
