// function allow you to create a reusable piece of code.
// DRY (do not repeat yourself)

function sayHello(name) {
  return `Hello ${name} !`;
}

console.log(sayHello("John"));

function sumTwoNumbers(a, b) {
  return a + b;
}

console.log(sumTwoNumbers(1, 2));

function multiply(a, b, c) {
  return a * b * c;
}

// this is a function definition
function displayMessage(temperature) {
  if (temperature >= 85) {
    return "it's very hot";
  } else if (temperature >= 70) {
    return "it's hot, but not too much";
  } else if (temperature >= 60) {
    return "the weather is really pleasant";
  } else {
    return "it's freezing";
  }
}

// we are going to invoke the function

const temperature = 86;
console.log(displayMessage(temperature));

function saveMeintoAVariable(a, b, c) {
  return a * b * c;
}

const result = saveMeintoAVariable(1, 2, 3);
console.log(result);
