import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-task-list',
  imports: [CommonModule],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css'
})
export class TaskListComponent {

  task = {
    id: 1,
    title: "Grocery Shopping",
    description: "Buy groceries for the week",
    dueDate: "2026",
    completed: false
  }  

  taskList = [
    {
      id: 1,
      title: "Grocery Shopping",
      description: "Buy groceries for the week",
      dueDate: "2026",
      completed: false
    },
    {
      id: 2,
      title: "Buy bread",
      description: "Buy bread",
      dueDate: "2025",
      completed: false
    },  {
      id: 3,
      title: "cook leftovers",
      description: "cook that stuff that you have in the frige that you do not want to really eat",
      dueDate: "2030",
      completed: false
    },

  ]
}

// const object = {
//   name: "alex",
//   lastName: "d",
//   sayHello: function sayHello(){ console.log('hello')}
// }

// object.sayHello()

