import { Component } from '@angular/core';
import { Task } from '../models/task';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-task-list',
  imports: [CommonModule, FormsModule],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css',
})
export class TaskListComponent {
  taskList: Task[] = [
    {
      id: 1,
      title: 'Go buy bread',
      description: 'grocery store around the corner',
      completed: false,
      dueDate: '2023-10-01',
    },
    {
      id: 2,
      title: 'Go buy milk',
      description: 'lactose free milk please',
      completed: false,
      dueDate: '2023-10-01',
    },
    {
      id: 3,
      title: 'Go buy eggs',
      description: 'the free range please',
      completed: false,
      dueDate: '2023-10-01',
    },
  ];

  newTask: Task = {
    id: 0,
    title: '',
    description: '',
    dueDate: '',
    completed: false,
  };
  addTask() {
    const tempTask: Task = {
      id: this.taskList.length + 1,
      title: this.newTask.title,
      description: this.newTask.description,
      dueDate: this.newTask.dueDate,
      completed: this.newTask.completed,
    };
    this.taskList.push(tempTask);
  }
  deleteTask(taskId: number){
    console.log(taskId)
    this.taskList = this.taskList.filter(task => task.id !== taskId)
  }
}

