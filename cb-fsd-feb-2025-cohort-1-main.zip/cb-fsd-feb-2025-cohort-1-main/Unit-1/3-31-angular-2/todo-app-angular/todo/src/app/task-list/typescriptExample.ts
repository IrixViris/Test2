// simple user object

// const user = {
//     name: "John Doe",
//     age: 30,
//     email: "john@example.com",
//     active: true
// }

// // this is an example of an array

// const users = [
//     {
//         name: "John Doe",
//         age: 30,
//         email: "john@example.com",
//         active: true
//     },
//     {
//         name: "John Smith",
//         age: 35,
//         email: "johnS@example.com",
//         active: false
//     },
// ]

// function findUserByEmail(email) {
//     return users.find(user => user.email === email);
// }

interface User {
    name: string;
    age: number;
    email: string;
    active: boolean;
}

const user: User = {
    name: 'hello',
    age: 30,
    email: 'a@hmail.com',
    active: true,
}
const users: User[] = [
    {
        name: "John Smith",
        email: "john@example.com",
        age: 24,
        active: true,
    }
]

function findUserByEmail(email: string){
    return users.find(user => user.email === email);
}
console.log(findUserByEmail(23))