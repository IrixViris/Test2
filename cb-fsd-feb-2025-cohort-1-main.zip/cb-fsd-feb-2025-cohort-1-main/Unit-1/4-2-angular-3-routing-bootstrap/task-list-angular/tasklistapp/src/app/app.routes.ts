import { Routes } from '@angular/router';
import { TaskListComponent } from './task-list/task-list.component';
import { HomeComponent } from './home/home.component';

export const routes: Routes = [
    {path: '', redirectTo: 'tasks', pathMatch: 'full' }, //takes you to the home page automatically
    {path: 'tasks', component: TaskListComponent}, //route to take you to the home page
    {path: 'home', component: HomeComponent}
];  
