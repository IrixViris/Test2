import { Component } from '@angular/core';
import { Task } from '../models/task';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-task-list',
  imports: [CommonModule, FormsModule],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css'
})
export class TaskListComponent {
  task: Task = {
    id: 1,
    title: "hello",
    description: "description",
    dueDate: '2023-10-10',
    completed: false,

  }
  taskList: Task[] = [
    {
      id: 1,
      title: 'Grocery Shopping',
      description: 'Buy groceries for the week.',
      dueDate: '2023-10-10',
      completed: false,
    },
    {
      id: 2,
      title: 'Laundry',
      description: 'Wash and fold clothes.',
      dueDate: '2023-10-11',
      completed: true,
    },
    {
      id: 3,
      title: 'Project Deadline',
      description: 'Submit project report.',
      dueDate: '2023-10-15',
      completed: false,
    },
  ];

  newTask: Task = {
    id: 0,
    title: '',
    description: '',
    dueDate: '',
    completed: false
  }

  addTask(){
    const tempTask : Task = {
      id: this.taskList.length + 1,
      title: this.newTask.title,
      description: this.newTask.description,
      dueDate: this.newTask.dueDate,
      completed: this.newTask.completed
    }
    console.log("Clicked!")
    console.log(tempTask)
    this.taskList.push(tempTask)
  }
  deleteTask(taskId: number){
    this.taskList = this.taskList.filter(task=> task.id !== taskId)
  }

}
