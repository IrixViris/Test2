console.log('first task')
setTimeout(() => {
    console.log('second task')
}, 3000)
console.log('third task')
