/**
 * AllLoopExamples.java
 * This class contains several examples of different types of loops in Java
 * Designed for students learning loops in their first lesson
 */
public class AllLoopExamples {
    public static void main(String[] args) {
        // EXAMPLE 1: Basic for loop
        System.out.println("\n----- EXAMPLE 1: Basic for loop -----");

        // The for loop has 3 parts:
        // 1. Initialization: int i = 1
        // 2. Condition: i <= 5
        // 3. Increment: i++
        for (int i = 1; i <= 5; i++) {
            System.out.println("Count: " + i);
        }

        // EXAMPLE 2: while loop
        System.out.println("\n----- EXAMPLE 2: While loop -----");

        // Initialize counter outside the loop
        int count = 5;

        // The loop runs as long as the condition is true
        while (count > 0) {
            System.out.println("Countdown: " + count);
            // Decrement the counter
            count--;
        }

        System.out.println("Blast off!");

        // EXAMPLE 3: do-while loop
        System.out.println("\n----- EXAMPLE 3: Do-while loop -----");

        int i = 1;

        // The code inside the loop runs first, then the condition is checked
        do {
            System.out.println("Iteration: " + i);
            i++;
        } while (i <= 3); // Semicolon is required here

        // EXAMPLE 4: for loop to iterate through an array
        System.out.println("\n----- EXAMPLE 4: Looping through an array -----");

        // Create an array of fruits
        String[] fruits = {"Apple", "Banana", "Cherry", "Date", "Elderberry"};

        // Loop through each element in the array
        for (int j = 0; j < fruits.length; j++) {
            System.out.println("Fruit " + (j + 1) + ": " + fruits[j]);
        }

        // EXAMPLE 5: Enhanced for loop (for-each loop)
        System.out.println("\n----- EXAMPLE 5: Enhanced for loop (for-each) -----");

        String[] colors = {"Red", "Green", "Blue", "Yellow", "Purple"};

        // This simpler syntax iterates through each element
        // without needing an index variable
        for (String color : colors) {
            System.out.println("Color: " + color);
        }

        // EXAMPLE 6: Nested loops (a loop inside another loop)
        System.out.println("\n----- EXAMPLE 6: Nested loops -----");

        // This creates a small multiplication table
        for (int row = 1; row <= 3; row++) {
            for (int col = 1; col <= 3; col++) {
                System.out.print(row + "×" + col + "=" + (row * col) + "\t");
            }
            // After each row, print a new line
            System.out.println();
        }

        // EXAMPLE 7: Loop with break statement
        System.out.println("\n----- EXAMPLE 7: Loop with break -----");

        for (int k = 1; k <= 10; k++) {
            System.out.println("Number: " + k);

            // When k reaches 5, break out of the loop
            if (k == 5) {
                System.out.println("Breaking the loop at 5");
                break;
            }
        }

        // EXAMPLE 8: Loop with continue statement
        System.out.println("\n----- EXAMPLE 8: Loop with continue -----");

        // Print only odd numbers from 1 to 10
        for (int m = 1; m <= 10; m++) {
            // If number is even, skip the rest of this iteration
            if (m % 2 == 0) {
                continue;
            }

            System.out.println("Odd number: " + m);
        }
    }
}