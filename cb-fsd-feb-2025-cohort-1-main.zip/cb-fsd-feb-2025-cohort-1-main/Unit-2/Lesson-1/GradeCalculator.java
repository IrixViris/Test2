import java.util.Scanner;

public class GradeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your score (0-100): ");
        int score = scanner.nextInt();

        char grade;

        // Using if-else ladder
        if (score >= 90) {
            grade = 'A';
        } else if (score >= 80) {
            grade = 'B';
        } else if (score >= 70) {
            grade = 'C';
        } else if (score >= 60) {
            grade = 'D';
        } else {
            grade = 'F';
        }

        System.out.println("Your grade is: " + grade);

        switch (grade) {
            case 'A':
                System.out.println("Excellent performance!");
                break;
            case 'B':
                System.out.println("Good job!");
                break;
            case 'C':
                System.out.println("Satisfactory result.");
                break;
            case 'D':
                System.out.println("You passed, but you can do better.");
                break;
            case 'F':
                System.out.println("Sorry, you failed. Please try again.");
                break;
            default:
                System.out.println("Invalid grade.");
        }

        String result = (score >= 60) ? "Pass" : "Fail";
        System.out.println("Result: " + result);

        scanner.close();
    }
}