public class Operator {


        public static void main(String[] args) {
            // Variables for demonstration
            int a = 10;
            int b = 3;
            boolean condition1 = true;
            boolean condition2 = false;

            // Arithmetic operators
            System.out.println("Arithmetic Operators:");
            System.out.println("a + b = " + (a + b));
            System.out.println("a - b = " + (a - b));
            System.out.println("a * b = " + (a * b));
            System.out.println("a / b = " + (a / b));  // Integer division
            System.out.println("a % b = " + (a % b));  // Remainder

            int c = a++;  // Post-increment
            System.out.println("c = a++ results in c = " + c + " and a = " + a);

            int d = ++b;  // Pre-increment
            System.out.println("d = ++b results in d = " + d + " and b = " + b);

            // Comparison operators
            System.out.println("\nComparison Operators:");
            System.out.println("a == b is " + (a == b));
            System.out.println("a != b is " + (a != b));
            System.out.println("a > b is " + (a > b));
            System.out.println("a < b is " + (a < b));
            System.out.println("a >= b is " + (a >= b));
            System.out.println("a <= b is " + (a <= b));

            // Logical operators
            System.out.println("\nLogical Operators:");
            System.out.println("condition1 && condition2 is " + (condition1 && condition2));
            System.out.println("condition1 || condition2 is " + (condition1 || condition2));
            System.out.println("!condition1 is " + (!condition1));

            // Assignment operators
            System.out.println("\nAssignment Operators:");
            int x = 10;
            System.out.println("Original x = " + x);

            x += 5;  // x = x + 5
            System.out.println("After x += 5, x = " + x);

            x -= 3;  // x = x - 3
            System.out.println("After x -= 3, x = " + x);

            x *= 2;  // x = x * 2
            System.out.println("After x *= 2, x = " + x);

            x /= 4;  // x = x / 4
            System.out.println("After x /= 4, x = " + x);

            x %= 3;  // x = x % 3
            System.out.println("After x %= 3, x = " + x);
        }
    }

