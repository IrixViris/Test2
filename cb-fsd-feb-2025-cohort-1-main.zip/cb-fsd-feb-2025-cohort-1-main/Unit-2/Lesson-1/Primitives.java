public class Primitives {
            public static void main(String[] args) {
                // Integer types
                byte myByte = 127; // Max value of byte
                short myShort = 32_767; // Max value of short
                int myInt = 2_147_483_647; // Max value of int
                long myLong = 9_223_372_036_854_775_807L; // Max value of long (add L)

                // Floating-point types
                float myFloat = 3.4028235E38f; // Max value of float (add f)
                double myDouble = 1.7976931348623157E308; // Max value of double

                // Character type
                char myChar = 'A'; // Stores a single character
                char unicodeChar = '\u0041'; // Unicode for 'A'

                // Boolean type
                boolean myBoolean = true; // Can be true or false

                // Printing all primitives and their ranges
                System.out.println("Primitive Data Types in Java:");
                System.out.println("byte: " + myByte + " (Min: " + Byte.MIN_VALUE + ", Max: " + Byte.MAX_VALUE + ")");
                System.out.println("short: " + myShort + " (Min: " + Short.MIN_VALUE + ", Max: " + Short.MAX_VALUE + ")");
                System.out.println("int: " + myInt + " (Min: " + Integer.MIN_VALUE + ", Max: " + Integer.MAX_VALUE + ")");
                System.out.println("long: " + myLong + "L (Min: " + Long.MIN_VALUE + ", Max: " + Long.MAX_VALUE + ")");
                System.out.println("float: " + myFloat + "f (Min: " + Float.MIN_VALUE + ", Max: " + Float.MAX_VALUE + ")");
                System.out
                        .println("double: " + myDouble + " (Min: " + Double.MIN_VALUE + ", Max: " + Double.MAX_VALUE + ")");
                System.out.println("char: " + myChar + " (Unicode: " + (int) myChar + ")");
                System.out.println("char (Unicode example): " + unicodeChar + " (Unicode: " + (int) unicodeChar + ")");
                System.out.println("boolean: " + myBoolean + " (Values: true/false)");
            }
        }
