public class TypeCasting {

        public static void main(String[] args) {
            int smallNumber = 10;
            double biggerNumber = (double)smallNumber;
            System.out.println("Implicit Casting (int to double): " + biggerNumber);
            double decimalNumber = 9.78;
            int wholeNumber = (int)decimalNumber;
            System.out.println("Explicit Casting (double to int): " + wholeNumber);
            char letter = 65;
            System.out.println("Char to int (ASCII value): " + letter);
            int num = 66;
            char letterFromInt = (char)num;
            System.out.println("Int to char: " + letterFromInt);
            int largeInt = 130;
            byte smallByte = (byte)largeInt;
            System.out.println("Overflowed Byte (130 to byte): " + smallByte);
        }
    }

